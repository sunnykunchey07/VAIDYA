# Mofiza--Humanoid-social-robot
Watch the Mofiza in action https://www.youtube.com/watch?v=CdclcoZlOCw

This Robot - Mofiza- Can SEE, TALK and REACT to her surroundings.
Ever since I've seen making talking robots I saw that people actually use other development boards rather than Arduino to make talking robots. But it's completely possible to make a Humanoid robot with Arduino who can talk and add a lot of servos to make it move. It's too simple to make this. 

For detailed Instruction on how to make this please go to https://ashrafminhajfb.blogspot.com/2018/08/make-smart-humanoid-talking-robot-mofiza.html 

Feel free to mail for any query at ashraf_minhaj@yahoo.com
